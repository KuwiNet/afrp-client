'use strict';
'require view';
'require form';

return view.extend({
	render: function() {
		var m, s, o;

		m = new form.Map('afrp', _('AFRP frpc 客户端'),
			_('填写官网账号对应的 Client ID 与 Client Secret 后启用服务。所有参数可在「运行状态」页从官网一键导入。'));

		s = m.section(form.NamedSection, 'client', 'client', _('基础设置'));
		s.anonymous = true;
		s.addremove = false;

		o = s.option(form.Flag, 'enabled', _('启用服务'));
		o.default = '0';
		o.rmempty = false;
		o.description = _('保存并应用后按下面的参数以 OIDC 认证启动 frpc');

		o = s.option(form.Value, 'server_addr', _('服务器地址'));
		o.rmempty = false;
		o.placeholder = 'frps.example.com';
		o.validate = function(section_id, value) {
			if (!value)
				return _('请填写服务器地址');
			return true;
		};

		o = s.option(form.Value, 'server_port', _('服务器端口'));
		o.datatype = 'port';
		o.default = '7000';
		o.rmempty = false;

		o = s.option(form.Value, 'client_id', _('Client ID'));
		o.rmempty = false;
		o.placeholder = _('你的用户名');
		o.description = _('即官网账号用户名，见控制台或注册邮件');
		o.validate = function(section_id, value) {
			if (!value)
				return _('请填写 Client ID');
			return true;
		};

		o = s.option(form.Value, 'client_secret', _('Client Secret'));
		o.password = true;
		o.rmempty = false;
		o.placeholder = _('官网控制台 / 注册邮件中的密钥');
		o.validate = function(section_id, value) {
			if (!value)
				return _('请填写 Client Secret');
			return true;
		};

		o = s.option(form.Value, 'token_endpoint', _('Token Endpoint'));
		o.default = 'https://www.afrp.net/oidc/token.php';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!value)
				return _('请填写 Token Endpoint');
			if (!/^https?:\/\//.test(value))
				return _('需以 http:// 或 https:// 开头');
			return true;
		};

		o = s.option(form.Value, 'audience', _('Audience'));
		o.default = 'afrp.net';
		o.rmempty = false;

		o = s.option(form.Value, 'scope', _('Scope'));
		o.default = 'afrp';
		o.rmempty = false;

		o = s.option(form.Value, 'update_base', _('更新服务器地址'));
		o.placeholder = 'https://www.afrp.net';
		o.description = _('用于检查 frpc 核心更新，留空时自动取 Token Endpoint 的站点地址');
		o.validate = function(section_id, value) {
			if (value && !/^https?:\/\//.test(value))
				return _('需以 http:// 或 https:// 开头');
			return true;
		};

		o = s.option(form.ListValue, 'core_arch', _('frpc 架构'));
		o.value('', _('自动检测'));
		o.value('amd64', 'amd64（x86_64）');
		o.value('arm64', 'arm64（aarch64）');
		o.value('arm', 'arm（32 位）');
		o.value('386', '386（i386 及以上）');
		o.value('mips', 'mips（大端）');
		o.value('mipsle', 'mipsle（小端，如 mipsel_24kc）');
		o.value('mips64', 'mips64');
		o.value('mips64le', 'mips64le');
		o.value('riscv64', 'riscv64');
		o.value('loong64', 'loong64');
		o.rmempty = true;
		o.description = _('一般保持「自动检测」即可；自动识别错误时手动指定');

		return m.render();
	}
});
