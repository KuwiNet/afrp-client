'use strict';
'require view';
'require form';

return view.extend({
	render: function() {
		var m, s, o;

		m = new form.Map('afrp', _('隧道管理'),
			_('每条隧道对应一个本地服务。远程端口（tcp/udp）留空时由服务器自动分配；http/https 填自定义域名或子域名。保存并应用后自动重建 frpc 配置并重启服务。'));

		s = m.section(form.GridSection, 'proxy', _('隧道列表'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;

		o = s.option(form.Flag, 'enabled', _('启用'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('名称'));
		o.rmempty = false;
		o.placeholder = 'web';
		o.validate = function(section_id, value) {
			if (!value)
				return _('请填写名称');
			if (!/^[A-Za-z0-9_.-]+$/.test(value))
				return _('仅支持字母、数字与 . _ -');
			return true;
		};

		o = s.option(form.ListValue, 'type', _('类型'));
		o.value('tcp', 'tcp');
		o.value('udp', 'udp');
		o.value('http', 'http');
		o.value('https', 'https');
		o.value('stcp', 'stcp');
		o.value('sudp', 'sudp');
		o.value('xtcp', 'xtcp');
		o.default = 'tcp';
		o.rmempty = false;

		o = s.option(form.Value, 'local_ip', _('本地 IP'));
		o.default = '127.0.0.1';
		o.rmempty = false;

		o = s.option(form.Value, 'local_port', _('本地端口'));
		o.datatype = 'port';
		o.rmempty = false;

		o = s.option(form.Value, 'remote_port', _('远程端口'));
		o.datatype = 'port';
		o.depends('type', 'tcp');
		o.depends('type', 'udp');
		o.placeholder = _('自动分配');

		o = s.option(form.Value, 'subdomain', _('子域名'));
		o.depends('type', 'http');
		o.depends('type', 'https');
		o.placeholder = 'tun';

		o = s.option(form.Value, 'custom_domain', _('自定义域名'));
		o.depends('type', 'http');
		o.depends('type', 'https');
		o.placeholder = 'tun.example.com';

		o = s.option(form.Value, 'secret_key', _('密钥'));
		o.password = true;
		o.depends('type', 'stcp');
		o.depends('type', 'sudp');
		o.depends('type', 'xtcp');

		return m.render();
	}
});
